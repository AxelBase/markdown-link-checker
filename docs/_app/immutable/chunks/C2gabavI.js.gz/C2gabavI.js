import{T as a}from"./C9xfq8eb.js";a();
