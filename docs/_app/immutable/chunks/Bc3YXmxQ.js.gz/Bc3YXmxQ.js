const s=globalThis.__sveltekit_ant6fq?.base??"/markdown-link-checker",a=globalThis.__sveltekit_ant6fq?.assets??s??"";export{a,s as b};
