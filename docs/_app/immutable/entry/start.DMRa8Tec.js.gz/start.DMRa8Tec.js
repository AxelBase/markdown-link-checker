import{l as o,a as r}from"../chunks/D8z_zbqS.js";export{o as load_css,r as start};
